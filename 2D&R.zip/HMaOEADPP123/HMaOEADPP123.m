function HMaOEADPP123(Global)
% <algorithm> <H-N>
%  An New Many-Objective Optimization using Determinantal point processes


%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group

    %% Parameter setting
    
    theta = Global.ParameterSet(0);
    %% Generate random population
    Population = Global.Initialization();
    CA = Population;
    DA = Population;
    [z,znad]     = deal(min(Population.objs),max(Population.objs));
    nad=znad;
 
    %% Optimization
    while Global.NotTermination(CA)
    %t1=clock;
        [ParentC] = MS_123(CA,DA,Global.N,z,znad);
 %       t1=clock;
        Offspring  = HSRSGA(ParentC);
%        t2=clock;
%        e=etime(t2,t1);
    %    fprintf('%d\n',e);
        z = min(z,min(Offspring.objs,[],1));
        [DA]= UpdateDA_123(DA,Offspring,Global.N,Global);
        [CA] = UpdateCA_123(CA,Offspring,Global.N,z,znad,DA.objs,theta,Global);
        znad=max([max(DA.objs, [],1);max(CA.objs,[],1)]);
    end

end